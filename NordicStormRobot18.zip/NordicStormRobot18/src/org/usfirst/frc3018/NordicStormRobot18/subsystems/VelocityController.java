package org.usfirst.frc3018.NordicStormRobot18.subsystems;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.VelocityMeasPeriod;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.SpeedController;

public class VelocityController implements SpeedController {
	private WPI_TalonSRX m_controller;

	public VelocityController(WPI_TalonSRX controller) {
		 m_controller=controller;
		 
		 /* "full" output will scale to 11 volts */
		 m_controller.configVoltageCompSaturation(11.0, 10);
		 m_controller.enableVoltageCompensation(true); /* turn on the voltage compensation feature */
	        
	        /* tweak the voltage bus measurement filter,
	        * default is 32 cells in rolling average (1ms per sample) */
		 m_controller.configVoltageMeasurementFilter(32, 10);
	        
		 m_controller.configSelectedFeedbackSensor(FeedbackDevice.QuadEncoder, 0, 100);
		 m_controller.configVelocityMeasurementPeriod(VelocityMeasPeriod.Period_10Ms, 50);
		 
		 m_controller.config_kP(0, 1, 100);//PIDindx,value,timeout
		 m_controller.config_kI(0, 0, 100);//PIDindx,value,timeout
		 m_controller.config_kD(0, 20, 100);//PIDindx,value,timeout
		 m_controller.setSensorPhase(true);
	
		 }
	
	@Override
	public void pidWrite(double output) {
		// TODO Auto-generated method stub

	}

	@Override
	public void set(double speed) {
		m_controller.set(ControlMode.Velocity, speed*1400);
		//m_controller.set(speed);

	}

	@Override
	public double get() {
		//return m_controller.get()/4096;
		return m_controller.get();
	}

	@Override
	public void setInverted(boolean isInverted) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean getInverted() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void disable() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stopMotor() {
		// TODO Auto-generated method stub

	}

}
